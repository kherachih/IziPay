enum GradientIntensity { accent, soft, medium, hard }

enum OvoDialogTypeType { success, error, warning, informations }
