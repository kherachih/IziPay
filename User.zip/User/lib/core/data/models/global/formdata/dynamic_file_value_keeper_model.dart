import 'dart:io';

class DynamicFileValueKeeperModel {
  String key;
  File value;
  DynamicFileValueKeeperModel(this.key, this.value);
}
