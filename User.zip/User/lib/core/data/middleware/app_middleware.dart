abstract class AppMiddleware {
  void handleResponse(dynamic response);
}
